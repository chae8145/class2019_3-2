package kr.ac.daelim.uml.zoo;

public interface IFly {
	public void fly();

}
