package kr.ac.daelim.uml.zoo;

public class PigeonCry implements ICry{

	public void cry() {
		// TODO Auto-generated method stub
		
		System.out.println("비둘기가 운다.");
	}

}
