package kr.ac.daelim.uml.zoo;

public interface ICry {
	public void cry();

}
