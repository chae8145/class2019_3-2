package kr.ac.daelim.uml.zoo;

public class FlyWithWings implements IFly{

	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("날개로 펄럭이면서 난다.");
	}

}
