package kr.ac.daelim.uml.zoo;

public class BirdCry implements ICry{

	public void cry() {
		// TODO Auto-generated method stub
		
		System.out.println("새가 운다.");
		
	}

}
