package kr.ac.daelim.uml.zoo;

public class TigerCry implements ICry{

	public void cry() {
		// TODO Auto-generated method stub
		
		System.out.println("호랑이가 운다.");
	}

}
