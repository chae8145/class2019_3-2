package kr.ac.daelim.uml.zoo;

public class FlyNoWay implements IFly{

	public void fly() {
		// TODO Auto-generated method stub
		
		System.out.println("날지 못한다.");
		
	}

}
