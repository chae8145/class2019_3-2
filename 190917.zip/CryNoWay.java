package kr.ac.daelim.uml.zoo;

public class CryNoWay implements ICry{

	public void cry() {
		// TODO Auto-generated method stub
		
		System.out.println("안운다.");
		
	}

}
